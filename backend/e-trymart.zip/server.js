const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();
const app = express();
const path = require('path');
// const logger = require('./logger');

const User = require('./models/User');
const userRoutes = require('./routes/UserRoutes');
const authRoutes = require('./routes/AuthRoutes');
const accountRoutes = require('./routes/AccountRoutes');


app.use(cors());
// app.use(express.json());

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));




// CRUD OPERATION ROUTES
app.use('/api/users', userRoutes);


// AUTHENTICATION  ROUTES
app.use('/api/auth', authRoutes);
app.use('/api', accountRoutes);

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));


mongoose.connect(process.env.MONGO_URI, { connectTimeoutMS: 30000 }).then(() => {
  console.log('MongoDB connected')
}).catch(err => {console.error(err), nlogger.info(err)});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server on http://localhost:${PORT}`));